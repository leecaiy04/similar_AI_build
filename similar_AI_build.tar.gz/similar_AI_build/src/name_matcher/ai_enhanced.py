"""
AI 增强的项目名称匹配器

基于传统算法 + 语义嵌入 + LLM 判断的多层次匹配架构
"""

import re
import json
from typing import List, Tuple, Dict, Optional, Any
from difflib import SequenceMatcher
import pandas as pd
from loguru import logger


class AIEnhancedMatcher:
    """AI 增强的项目名称匹配器"""
    
    def __init__(
        self,
        use_embedding: bool = True,
        use_llm: bool = False,
        llm_threshold_range: Tuple[float, float] = (0.5, 0.8),
        weights: Optional[Dict[str, float]] = None
    ):
        """
        初始化 AI 增强匹配器
        
        Args:
            use_embedding: 是否使用嵌入向量（需要安装 sentence-transformers）
            use_llm: 是否使用 LLM 判断（需要配置 API）
            llm_threshold_range: LLM 介入的分数范围（仅在此范围内调用 LLM）
            weights: 各特征权重字典
        """
        self.use_embedding = use_embedding
        self.use_llm = use_llm
        self.llm_threshold_range = llm_threshold_range
        
        # 默认权重
        self.weights = weights or {
            'edit': 0.15,
            'token_set': 0.20,
            'ngram': 0.15,
            'tfidf': 0.10,
            'embedding': 0.30,
            'llm': 0.10
        }
        
        # 缓存
        self.cache = {}
        self.embedding_cache = {}
        
        # 加载嵌入模型
        if self.use_embedding:
            self._load_embedding_model()
        
        # 别名词典
        self.alias_dict = {
            '系统': ['system', '平台', 'platform'],
            '管理': ['management', 'admin', '后台', 'manage'],
            '数据': ['data', '信息', '资料'],
            '分析': ['analysis', 'analytics', '统计'],
            '用户': ['user', '客户', 'customer'],
            '订单': ['order', '工单'],
            '项目': ['project', '工程'],
            '财务': ['finance', '财会', 'financial'],
        }
        
        # 版本号正则
        self.version_pattern = re.compile(
            r'[\s\-_]*(?:v|version|版本)?[\s\-_]*\d+(?:\.\d+)*(?:[\s\-_]*(?:旧版|新版|old|new))?\b',
            re.IGNORECASE
        )
        
        logger.info(
            f"AI增强匹配器初始化完成 "
            f"(Embedding: {use_embedding}, LLM: {use_llm})"
        )
    
    def _load_embedding_model(self):
        """加载嵌入模型"""
        try:
            from sentence_transformers import SentenceTransformer
            # 使用多语言模型
            self.embedding_model = SentenceTransformer(
                'paraphrase-multilingual-MiniLM-L12-v2'
            )
            logger.success("已加载 Sentence-BERT 多语言模型")
        except ImportError:
            logger.warning(
                "sentence-transformers 未安装，嵌入功能不可用\n"
                "安装命令: pip install sentence-transformers"
            )
            self.use_embedding = False
        except Exception as e:
            logger.error(f"加载嵌入模型失败: {e}")
            self.use_embedding = False
    
    def normalize(self, name: str) -> str:
        """标准化项目名称"""
        if not name:
            return ""
        
        normalized = name.strip().lower()
        # 移除特殊字符
        normalized = re.sub(r'[^\w\s\u4e00-\u9fff-]', ' ', normalized)
        # 压缩空格
        normalized = re.sub(r'\s+', ' ', normalized)
        return normalized.strip()
    
    def extract_core_name(self, name: str) -> str:
        """提取核心名称（移除版本号等）"""
        # 移除版本号
        core = self.version_pattern.sub('', name)
        # 移除括号内容
        core = re.sub(r'\([^)]*\)', '', core)
        core = re.sub(r'\[[^\]]*\]', '', core)
        # 标准化
        return self.normalize(core)
    
    def expand_with_aliases(self, name: str) -> List[str]:
        """使用别名词典扩展名称"""
        expanded = [name]
        normalized = self.normalize(name)
        
        for key, aliases in self.alias_dict.items():
            if key in normalized:
                for alias in aliases:
                    expanded.append(normalized.replace(key, alias))
        
        return expanded
    
    # ==================== 第一层：规则判断 ====================
    
    def rule_based_check(self, name1: str, name2: str) -> Optional[Tuple[bool, float, str]]:
        """基于规则的快速判断"""
        # 完全相同
        if name1 == name2:
            return True, 1.0, "完全匹配"
        
        # 标准化后相同
        norm1 = self.normalize(name1)
        norm2 = self.normalize(name2)
        if norm1 == norm2:
            return True, 0.98, "标准化后匹配"
        
        # 核心名称相同
        core1 = self.extract_core_name(name1)
        core2 = self.extract_core_name(name2)
        if core1 and core2 and core1 == core2:
            return True, 0.95, "核心名称匹配（版本号差异）"
        
        # 长度差异过大
        if max(len(norm1), len(norm2)) / (min(len(norm1), len(norm2)) + 1) > 3:
            return False, 0.1, "长度差异过大"
        
        return None
    
    # ==================== 第二层：传统算法 ====================
    
    def levenshtein_distance(self, s1: str, s2: str) -> int:
        """计算编辑距离"""
        if len(s1) < len(s2):
            return self.levenshtein_distance(s2, s1)
        
        if len(s2) == 0:
            return len(s1)
        
        previous_row = range(len(s2) + 1)
        for i, c1 in enumerate(s1):
            current_row = [i + 1]
            for j, c2 in enumerate(s2):
                insertions = previous_row[j + 1] + 1
                deletions = current_row[j] + 1
                substitutions = previous_row[j] + (c1 != c2)
                current_row.append(min(insertions, deletions, substitutions))
            previous_row = current_row
        
        return previous_row[-1]
    
    def edit_similarity(self, name1: str, name2: str) -> float:
        """编辑距离相似度"""
        n1 = self.normalize(name1)
        n2 = self.normalize(name2)
        
        if not n1 or not n2:
            return 0.0
        
        max_len = max(len(n1), len(n2))
        distance = self.levenshtein_distance(n1, n2)
        return 1 - (distance / max_len)
    
    def token_set_similarity(self, name1: str, name2: str) -> float:
        """词集相似度（Jaccard）"""
        tokens1 = set(self.normalize(name1).split())
        tokens2 = set(self.normalize(name2).split())
        
        if not tokens1 or not tokens2:
            return 0.0
        
        intersection = len(tokens1 & tokens2)
        union = len(tokens1 | tokens2)
        return intersection / union if union > 0 else 0.0
    
    def ngram_similarity(self, name1: str, name2: str, n: int = 2) -> float:
        """N-gram 相似度"""
        def get_ngrams(text: str, n: int) -> set:
            text = self.normalize(text).replace(' ', '')
            return set([text[i:i+n] for i in range(len(text) - n + 1)])
        
        ngrams1 = get_ngrams(name1, n)
        ngrams2 = get_ngrams(name2, n)
        
        if not ngrams1 or not ngrams2:
            return 0.0
        
        intersection = len(ngrams1 & ngrams2)
        union = len(ngrams1 | ngrams2)
        return intersection / union if union > 0 else 0.0
    
    def sequence_similarity(self, name1: str, name2: str) -> float:
        """序列匹配相似度"""
        n1 = self.normalize(name1)
        n2 = self.normalize(name2)
        return SequenceMatcher(None, n1, n2).ratio()
    
    # ==================== 第三层：AI 语义 ====================
    
    def get_embedding(self, name: str) -> Optional[Any]:
        """获取文本嵌入向量（带缓存）"""
        if not self.use_embedding:
            return None
        
        if name in self.embedding_cache:
            return self.embedding_cache[name]
        
        try:
            embedding = self.embedding_model.encode(name, convert_to_tensor=False)
            self.embedding_cache[name] = embedding
            return embedding
        except Exception as e:
            logger.error(f"生成嵌入向量失败: {e}")
            return None
    
    def embedding_similarity(self, name1: str, name2: str) -> float:
        """基于嵌入向量的语义相似度"""
        if not self.use_embedding:
            return 0.0
        
        emb1 = self.get_embedding(name1)
        emb2 = self.get_embedding(name2)
        
        if emb1 is None or emb2 is None:
            return 0.0
        
        try:
            from sklearn.metrics.pairwise import cosine_similarity
            import numpy as np
            
            similarity = cosine_similarity(
                np.array(emb1).reshape(1, -1),
                np.array(emb2).reshape(1, -1)
            )[0][0]
            
            return float(similarity)
        except Exception as e:
            logger.error(f"计算嵌入相似度失败: {e}")
            return 0.0
    
    def llm_judge(self, name1: str, name2: str) -> Tuple[bool, float, str]:
        """
        使用 LLM 判断（需要实现）
        
        Returns:
            (是否同一项目, 置信度分数, 原因说明)
        """
        if not self.use_llm:
            return False, 0.5, "LLM 未启用"
        
        # 这里需要接入实际的 LLM API
        # 示例：调用 OpenAI API 或本地 LLM
        
        prompt = f"""
请判断以下两个项目名称是否指向同一个项目：

项目名称A: {name1}
项目名称B: {name2}

判断标准：
1. 核心功能是否相同
2. 语义含义是否一致
3. 忽略版本号、平台差异、表述方式差异

请以 JSON 格式返回：
{{
    "is_same": true/false,
    "confidence": 0.0-1.0,
    "reason": "判断原因"
}}
"""
        
        # TODO: 实现 LLM 调用
        # response = call_llm_api(prompt)
        # result = json.loads(response)
        # return result['is_same'], result['confidence'], result['reason']
        
        logger.warning("LLM 判断功能需要配置 API")
        return False, 0.5, "LLM API 未配置"
    
    # ==================== 决策融合 ====================
    
    def calculate_weighted_score(self, features: Dict[str, float]) -> float:
        """计算加权融合分数"""
        total_weight = sum(
            self.weights.get(key, 0) 
            for key in features.keys()
        )
        
        if total_weight == 0:
            return 0.0
        
        score = sum(
            features[key] * self.weights.get(key, 0)
            for key in features.keys()
        )
        
        return score / total_weight if total_weight > 0 else 0.0
    
    def is_same_project(
        self, 
        name1: str, 
        name2: str,
        return_details: bool = False
    ) -> Tuple[bool, float, str] | Tuple[bool, float, str, Dict]:
        """
        判断两个项目名称是否为同一项目
        
        Args:
            name1: 项目名称1
            name2: 项目名称2
            return_details: 是否返回详细特征
            
        Returns:
            (是否同一项目, 置信度分数, 判断依据[, 详细特征])
        """
        # 检查缓存
        cache_key = tuple(sorted([name1, name2]))
        if cache_key in self.cache:
            cached = self.cache[cache_key]
            if return_details:
                return cached
            return cached[:3]
        
        # 第一层：规则快速判断
        rule_result = self.rule_based_check(name1, name2)
        if rule_result is not None:
            is_same, score, reason = rule_result
            features = {'rule': score}
            result = (is_same, score, reason, features)
            self.cache[cache_key] = result
            return result if return_details else result[:3]
        
        # 第二层：传统算法特征
        features = {
            'edit': self.edit_similarity(name1, name2),
            'token_set': self.token_set_similarity(name1, name2),
            'ngram': self.ngram_similarity(name1, name2),
        }
        
        logger.debug(f"传统算法特征: {features}")
        
        # 第三层：AI 语义特征
        if self.use_embedding:
            features['embedding'] = self.embedding_similarity(name1, name2)
            logger.debug(f"嵌入相似度: {features['embedding']:.4f}")
        
        # 计算初步分数
        score = self.calculate_weighted_score(features)
        
        # 边界情况调用 LLM
        if self.use_llm:
            min_thresh, max_thresh = self.llm_threshold_range
            if min_thresh <= score <= max_thresh:
                logger.info(f"边界情况 ({score:.4f})，调用 LLM 判断")
                llm_same, llm_score, llm_reason = self.llm_judge(name1, name2)
                features['llm'] = llm_score
                # 重新计算分数
                score = self.calculate_weighted_score(features)
        
        # 最终判断
        is_same = score >= 0.75
        
        if score >= 0.9:
            confidence = "高"
        elif score >= 0.7:
            confidence = "中"
        elif score >= 0.5:
            confidence = "低"
        else:
            confidence = "高（不同）"
        
        reason = f"综合相似度 {score:.4f} ({confidence}置信度)"
        
        result = (is_same, score, reason, features)
        self.cache[cache_key] = result
        
        return result if return_details else result[:3]
    
    def batch_compare(
        self, 
        names: List[str],
        threshold: float = 0.75
    ) -> pd.DataFrame:
        """
        批量比较项目名称，找出相似项
        
        Args:
            names: 项目名称列表
            threshold: 相似度阈值
            
        Returns:
            相似项 DataFrame
        """
        logger.info(f"批量比较 {len(names)} 个项目名称")
        
        results = []
        for i in range(len(names)):
            for j in range(i + 1, len(names)):
                is_same, score, reason, features = self.is_same_project(
                    names[i], names[j], return_details=True
                )
                
                if score >= threshold:
                    results.append({
                        '项目A': names[i],
                        '项目B': names[j],
                        '相似度': round(score, 4),
                        '判断': '同一项目' if is_same else '可能相同',
                        '原因': reason,
                        **{f'特征_{k}': round(v, 4) for k, v in features.items()}
                    })
        
        df = pd.DataFrame(results)
        logger.success(f"找到 {len(df)} 对相似项目")
        return df
    
    def clear_cache(self):
        """清空缓存"""
        self.cache.clear()
        self.embedding_cache.clear()
        logger.info("缓存已清空")
