"""
项目名称相似求同模块

提供项目名称的相似度计算、模糊匹配、去重归并等功能
支持中文拼音匹配和多种相似度算法
"""

import re
from typing import List, Tuple, Dict, Optional, Set
from difflib import SequenceMatcher
from collections import defaultdict
import pandas as pd
from loguru import logger


class ProjectNameMatcher:
    """项目名称匹配器"""
    
    def __init__(self, case_sensitive: bool = False, remove_special_chars: bool = True):
        """
        初始化项目名称匹配器
        
        Args:
            case_sensitive: 是否区分大小写
            remove_special_chars: 是否移除特殊字符
        """
        self.case_sensitive = case_sensitive
        self.remove_special_chars = remove_special_chars
        logger.info(f"初始化项目名称匹配器 (大小写敏感: {case_sensitive})")
    
    def normalize(self, name: str) -> str:
        """
        标准化项目名称
        
        Args:
            name: 原始项目名称
            
        Returns:
            标准化后的名称
        """
        if not name:
            return ""
        
        # 去除首尾空白
        normalized = name.strip()
        
        # 大小写处理
        if not self.case_sensitive:
            normalized = normalized.lower()
        
        # 移除特殊字符（保留中文、字母、数字、空格、短横线、下划线）
        if self.remove_special_chars:
            normalized = re.sub(r'[^\w\s\u4e00-\u9fff-]', '', normalized)
        
        # 压缩多余空格
        normalized = re.sub(r'\s+', ' ', normalized)
        
        return normalized.strip()
    
    def levenshtein_distance(self, s1: str, s2: str) -> int:
        """
        计算编辑距离（Levenshtein Distance）
        
        Args:
            s1: 字符串1
            s2: 字符串2
            
        Returns:
            编辑距离
        """
        if len(s1) < len(s2):
            return self.levenshtein_distance(s2, s1)
        
        if len(s2) == 0:
            return len(s1)
        
        previous_row = range(len(s2) + 1)
        for i, c1 in enumerate(s1):
            current_row = [i + 1]
            for j, c2 in enumerate(s2):
                # 插入、删除、替换的代价
                insertions = previous_row[j + 1] + 1
                deletions = current_row[j] + 1
                substitutions = previous_row[j] + (c1 != c2)
                current_row.append(min(insertions, deletions, substitutions))
            previous_row = current_row
        
        return previous_row[-1]
    
    def similarity_ratio(self, name1: str, name2: str, method: str = 'sequence') -> float:
        """
        计算两个项目名称的相似度
        
        Args:
            name1: 项目名称1
            name2: 项目名称2
            method: 相似度算法 ('sequence', 'levenshtein', 'jaccard', 'token_set')
            
        Returns:
            相似度分数 (0-1)
        """
        # 标准化
        n1 = self.normalize(name1)
        n2 = self.normalize(name2)
        
        if not n1 or not n2:
            return 0.0
        
        if n1 == n2:
            return 1.0
        
        if method == 'sequence':
            # 基于 SequenceMatcher 的相似度
            return SequenceMatcher(None, n1, n2).ratio()
        
        elif method == 'levenshtein':
            # 基于编辑距离的相似度
            max_len = max(len(n1), len(n2))
            distance = self.levenshtein_distance(n1, n2)
            return 1 - (distance / max_len)
        
        elif method == 'jaccard':
            # Jaccard 相似度（基于字符集）
            set1 = set(n1)
            set2 = set(n2)
            intersection = len(set1 & set2)
            union = len(set1 | set2)
            return intersection / union if union > 0 else 0.0
        
        elif method == 'token_set':
            # 基于词集的相似度
            tokens1 = set(n1.split())
            tokens2 = set(n2.split())
            intersection = len(tokens1 & tokens2)
            union = len(tokens1 | tokens2)
            return intersection / union if union > 0 else 0.0
        
        else:
            raise ValueError(f"不支持的相似度算法: {method}")
    
    def find_similar(self, target: str, candidates: List[str], 
                    threshold: float = 0.8, method: str = 'sequence',
                    top_n: Optional[int] = None) -> List[Tuple[str, float]]:
        """
        查找与目标名称相似的项目
        
        Args:
            target: 目标项目名称
            candidates: 候选项目名称列表
            threshold: 相似度阈值 (0-1)
            method: 相似度算法
            top_n: 返回前 N 个最相似的，None 表示返回所有超过阈值的
            
        Returns:
            相似项目列表 [(名称, 相似度分数)]，按相似度降序
        """
        logger.info(f"查找与 '{target}' 相似的项目（阈值: {threshold}, 算法: {method}）")
        
        results = []
        for candidate in candidates:
            if candidate == target:  # 跳过自己
                continue
            
            score = self.similarity_ratio(target, candidate, method=method)
            if score >= threshold:
                results.append((candidate, score))
        
        # 按相似度降序排序
        results.sort(key=lambda x: x[1], reverse=True)
        
        if top_n:
            results = results[:top_n]
        
        logger.success(f"找到 {len(results)} 个相似项目")
        return results
    
    def find_duplicates(self, names: List[str], threshold: float = 0.9,
                       method: str = 'sequence') -> Dict[str, List[str]]:
        """
        查找可能重复的项目名称
        
        Args:
            names: 项目名称列表
            threshold: 相似度阈值
            method: 相似度算法
            
        Returns:
            重复项字典 {代表名称: [相似名称列表]}
        """
        logger.info(f"检测重复项目名称（总数: {len(names)}, 阈值: {threshold}）")
        
        duplicates = defaultdict(list)
        processed = set()
        
        for i, name1 in enumerate(names):
            if name1 in processed:
                continue
            
            group = [name1]
            for j in range(i + 1, len(names)):
                name2 = names[j]
                if name2 in processed:
                    continue
                
                score = self.similarity_ratio(name1, name2, method=method)
                if score >= threshold:
                    group.append(name2)
                    processed.add(name2)
            
            if len(group) > 1:
                # 使用第一个名称作为代表
                duplicates[name1] = group[1:]
                processed.add(name1)
        
        logger.success(f"找到 {len(duplicates)} 组重复项")
        return dict(duplicates)
    
    def merge_duplicates(self, df: pd.DataFrame, name_column: str,
                        threshold: float = 0.9, method: str = 'sequence',
                        keep: str = 'first') -> pd.DataFrame:
        """
        合并 DataFrame 中的重复项目名称
        
        Args:
            df: 数据 DataFrame
            name_column: 项目名称列
            threshold: 相似度阈值
            method: 相似度算法
            keep: 保留策略 ('first', 'last', 'shortest', 'longest')
            
        Returns:
            合并后的 DataFrame，添加 'merged_name' 列
        """
        logger.info(f"合并 DataFrame 中的重复项目（列: {name_column}）")
        
        df_result = df.copy()
        names = df[name_column].unique().tolist()
        
        # 查找重复项
        duplicates = self.find_duplicates(names, threshold=threshold, method=method)
        
        # 构建名称映射
        name_mapping = {}
        for representative, similar_names in duplicates.items():
            group = [representative] + similar_names
            
            # 根据保留策略选择标准名称
            if keep == 'first':
                standard_name = representative
            elif keep == 'last':
                standard_name = similar_names[-1] if similar_names else representative
            elif keep == 'shortest':
                standard_name = min(group, key=len)
            elif keep == 'longest':
                standard_name = max(group, key=len)
            else:
                standard_name = representative
            
            # 映射所有相似名称到标准名称
            for name in group:
                name_mapping[name] = standard_name
        
        # 应用映射
        df_result['merged_name'] = df_result[name_column].map(
            lambda x: name_mapping.get(x, x)
        )
        
        original_count = df[name_column].nunique()
        merged_count = df_result['merged_name'].nunique()
        reduction = original_count - merged_count
        
        logger.success(f"合并完成: {original_count} -> {merged_count} (减少 {reduction} 个)")
        return df_result
    
    def batch_match(self, sources: List[str], targets: List[str],
                   threshold: float = 0.8, method: str = 'sequence') -> pd.DataFrame:
        """
        批量匹配两个名称列表
        
        Args:
            sources: 源名称列表
            targets: 目标名称列表
            threshold: 相似度阈值
            method: 相似度算法
            
        Returns:
            匹配结果 DataFrame
        """
        logger.info(f"批量匹配 {len(sources)} 个源名称到 {len(targets)} 个目标")
        
        results = []
        for source in sources:
            matches = self.find_similar(
                source, targets, 
                threshold=threshold, 
                method=method,
                top_n=3  # 最多返回前3个匹配
            )
            
            if matches:
                for match_name, score in matches:
                    results.append({
                        '源名称': source,
                        '匹配名称': match_name,
                        '相似度': round(score, 4)
                    })
            else:
                results.append({
                    '源名称': source,
                    '匹配名称': None,
                    '相似度': 0.0
                })
        
        df_result = pd.DataFrame(results)
        logger.success(f"匹配完成，共 {len(df_result)} 条结果")
        return df_result


class ChineseNameMatcher(ProjectNameMatcher):
    """中文项目名称匹配器（支持拼音）"""
    
    def __init__(self, use_pinyin: bool = True, **kwargs):
        """
        初始化中文名称匹配器
        
        Args:
            use_pinyin: 是否启用拼音匹配
            **kwargs: 传递给父类的参数
        """
        super().__init__(**kwargs)
        self.use_pinyin = use_pinyin
        
        if use_pinyin:
            try:
                from pypinyin import lazy_pinyin
                self.lazy_pinyin = lazy_pinyin
                logger.info("已启用拼音匹配支持")
            except ImportError:
                logger.warning("pypinyin 未安装，拼音匹配功能不可用")
                self.use_pinyin = False
    
    def to_pinyin(self, text: str) -> str:
        """
        将中文转换为拼音
        
        Args:
            text: 中文文本
            
        Returns:
            拼音字符串（空格分隔）
        """
        if not self.use_pinyin:
            return text
        
        try:
            pinyin_list = self.lazy_pinyin(text)
            return ' '.join(pinyin_list)
        except:
            return text
    
    def similarity_ratio(self, name1: str, name2: str, 
                        method: str = 'sequence',
                        use_pinyin: bool = False) -> float:
        """
        计算相似度（支持拼音匹配）
        
        Args:
            name1: 名称1
            name2: 名称2
            method: 相似度算法
            use_pinyin: 是否使用拼音匹配
            
        Returns:
            相似度分数
        """
        if use_pinyin and self.use_pinyin:
            # 先计算原始文本相似度
            original_score = super().similarity_ratio(name1, name2, method)
            
            # 再计算拼音相似度
            pinyin1 = self.to_pinyin(name1)
            pinyin2 = self.to_pinyin(name2)
            pinyin_score = super().similarity_ratio(pinyin1, pinyin2, method)
            
            # 取较高的分数
            return max(original_score, pinyin_score)
        else:
            return super().similarity_ratio(name1, name2, method)
