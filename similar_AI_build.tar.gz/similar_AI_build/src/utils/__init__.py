"""
工具函数模块

提供日志、配置、文件操作等辅助功能
"""

import os
import json
import yaml
from pathlib import Path
from typing import Any, Dict, Optional
from loguru import logger
import pandas as pd


def setup_logger(log_path: str = "logs/analysis.log", level: str = "INFO"):
    """
    配置日志系统
    
    Args:
        log_path: 日志文件路径
        level: 日志级别
    """
    log_dir = Path(log_path).parent
    log_dir.mkdir(parents=True, exist_ok=True)
    
    logger.add(
        log_path,
        rotation="10 MB",
        retention="30 days",
        level=level,
        format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}"
    )
    logger.info("日志系统初始化完成")


def load_config(config_path: str) -> Dict[str, Any]:
    """
    加载配置文件
    
    Args:
        config_path: 配置文件路径（支持 .json 和 .yaml）
        
    Returns:
        配置字典
    """
    path = Path(config_path)
    
    if not path.exists():
        raise FileNotFoundError(f"配置文件不存在: {config_path}")
    
    if path.suffix == '.json':
        with open(path, 'r', encoding='utf-8') as f:
            config = json.load(f)
    elif path.suffix in ['.yaml', '.yml']:
        with open(path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
    else:
        raise ValueError(f"不支持的配置文件格式: {path.suffix}")
    
    logger.info(f"成功加载配置文件: {config_path}")
    return config


def save_dataframe(df: pd.DataFrame, output_path: str, index: bool = False):
    """
    保存 DataFrame 到文件
    
    Args:
        df: 要保存的 DataFrame
        output_path: 输出路径
        index: 是否保存索引
    """
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    
    if path.suffix == '.csv':
        df.to_csv(output_path, index=index, encoding='utf-8-sig')
    elif path.suffix in ['.xlsx', '.xls']:
        df.to_excel(output_path, index=index)
    elif path.suffix == '.json':
        df.to_json(output_path, orient='records', force_ascii=False, indent=2)
    elif path.suffix == '.parquet':
        df.to_parquet(output_path, index=index)
    else:
        raise ValueError(f"不支持的文件格式: {path.suffix}")
    
    logger.success(f"数据已保存至: {output_path}")


def ensure_dir(dir_path: str):
    """
    确保目录存在，不存在则创建
    
    Args:
        dir_path: 目录路径
    """
    Path(dir_path).mkdir(parents=True, exist_ok=True)


def get_project_root() -> Path:
    """
    获取项目根目录
    
    Returns:
        项目根目录路径
    """
    return Path(__file__).parent.parent.parent


def memory_usage_info(df: pd.DataFrame) -> Dict[str, Any]:
    """
    获取 DataFrame 内存使用信息
    
    Args:
        df: DataFrame
        
    Returns:
        内存使用信息字典
    """
    memory_bytes = df.memory_usage(deep=True).sum()
    memory_mb = memory_bytes / (1024 ** 2)
    
    info = {
        '总行数': len(df),
        '总列数': len(df.columns),
        '内存使用(MB)': round(memory_mb, 2),
        '平均每行(KB)': round((memory_bytes / len(df)) / 1024, 2) if len(df) > 0 else 0
    }
    
    logger.info(f"内存使用: {info['内存使用(MB)']} MB")
    return info


def optimize_dtypes(df: pd.DataFrame) -> pd.DataFrame:
    """
    优化 DataFrame 数据类型以减少内存使用
    
    Args:
        df: 原始 DataFrame
        
    Returns:
        优化后的 DataFrame
    """
    df_optimized = df.copy()
    
    # 优化整数类型
    int_cols = df_optimized.select_dtypes(include=['int64']).columns
    for col in int_cols:
        df_optimized[col] = pd.to_numeric(df_optimized[col], downcast='integer')
    
    # 优化浮点数类型
    float_cols = df_optimized.select_dtypes(include=['float64']).columns
    for col in float_cols:
        df_optimized[col] = pd.to_numeric(df_optimized[col], downcast='float')
    
    # 优化对象类型（转换为 category）
    obj_cols = df_optimized.select_dtypes(include=['object']).columns
    for col in obj_cols:
        num_unique = df_optimized[col].nunique()
        num_total = len(df_optimized[col])
        if num_unique / num_total < 0.5:  # 如果唯一值比例小于 50%
            df_optimized[col] = df_optimized[col].astype('category')
    
    original_memory = df.memory_usage(deep=True).sum() / (1024 ** 2)
    optimized_memory = df_optimized.memory_usage(deep=True).sum() / (1024 ** 2)
    reduction = ((original_memory - optimized_memory) / original_memory) * 100
    
    logger.info(f"内存优化完成: {original_memory:.2f}MB -> {optimized_memory:.2f}MB (减少 {reduction:.1f}%)")
    return df_optimized
