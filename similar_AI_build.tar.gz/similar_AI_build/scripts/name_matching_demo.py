#!/usr/bin/env python3
"""
项目名称相似求同示例脚本

演示如何使用 name_matcher 模块进行项目名称的相似度匹配和去重
"""

import sys
from pathlib import Path

# 添加项目根目录到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import pandas as pd
from src.name_matcher import ProjectNameMatcher, ChineseNameMatcher
from src.utils import setup_logger, save_dataframe

# 设置日志
setup_logger()


def demo_basic_similarity():
    """演示基础相似度计算"""
    print("=" * 60)
    print("示例 1: 基础相似度计算")
    print("=" * 60)
    
    matcher = ProjectNameMatcher()
    
    # 测试案例
    test_pairs = [
        ("数据分析平台", "数据分析系统"),
        ("User Management System", "User Management Sys"),
        ("项目管理工具", "项目管理"),
        ("AI-Assistant", "AI Assistant"),
        ("DataAnalytics2024", "data_analytics_2024"),
    ]
    
    print("\n不同相似度算法对比：\n")
    for name1, name2 in test_pairs:
        print(f"名称1: {name1}")
        print(f"名称2: {name2}")
        
        for method in ['sequence', 'levenshtein', 'jaccard', 'token_set']:
            score = matcher.similarity_ratio(name1, name2, method=method)
            print(f"  {method:12s}: {score:.4f}")
        print()


def demo_find_similar():
    """演示查找相似项目"""
    print("=" * 60)
    print("示例 2: 查找相似项目")
    print("=" * 60)
    
    # 创建项目名称列表
    projects = [
        "数据分析平台",
        "数据分析系统",
        "数据可视化平台",
        "用户管理系统",
        "用户管理平台",
        "客户管理系统",
        "订单管理系统",
        "订单处理系统",
        "财务报表系统",
        "财务分析系统",
    ]
    
    matcher = ProjectNameMatcher()
    target = "数据分析系统"
    
    print(f"\n目标项目: {target}")
    print(f"候选项目数: {len(projects)}")
    print(f"\n相似项目（阈值 0.7）:\n")
    
    similar = matcher.find_similar(target, projects, threshold=0.7, top_n=5)
    
    for i, (name, score) in enumerate(similar, 1):
        print(f"{i}. {name:20s} (相似度: {score:.4f})")


def demo_find_duplicates():
    """演示查找重复项目"""
    print("\n" + "=" * 60)
    print("示例 3: 查找重复项目")
    print("=" * 60)
    
    # 创建包含重复项的项目列表
    projects = [
        "数据分析平台v1",
        "数据分析平台 v1.0",
        "数据分析平台(v1)",
        "用户管理系统",
        "用户管理系统2.0",
        "User Management System",
        "订单处理系统",
        "订单处理平台",
        "财务报表工具",
        "财务分析系统",
        "AI智能助手",
        "AI 智能助手",
        "AI-智能助手",
    ]
    
    matcher = ProjectNameMatcher()
    
    print(f"\n原始项目数: {len(projects)}")
    print("\n检测到的重复项:\n")
    
    duplicates = matcher.find_duplicates(projects, threshold=0.85)
    
    for i, (representative, similar_list) in enumerate(duplicates.items(), 1):
        print(f"{i}. 代表名称: {representative}")
        print(f"   相似项目:")
        for similar in similar_list:
            score = matcher.similarity_ratio(representative, similar)
            print(f"     - {similar} (相似度: {score:.4f})")
        print()


def demo_merge_dataframe():
    """演示 DataFrame 中的项目名称去重"""
    print("=" * 60)
    print("示例 4: DataFrame 项目名称去重")
    print("=" * 60)
    
    # 创建示例数据
    data = {
        '项目名称': [
            '数据分析平台',
            '数据分析平台v2',
            '用户管理系统',
            '用户管理系统2.0',
            '订单处理系统',
            '订单处理平台',
            '财务报表工具',
            '营销活动管理',
            '数据分析平台',  # 完全重复
        ],
        '负责人': ['张三', '李四', '王五', '赵六', '钱七', '孙八', '周九', '吴十', '张三'],
        '预算': [100, 120, 80, 90, 70, 75, 60, 50, 100],
        '状态': ['进行中', '进行中', '已完成', '进行中', '已完成', '进行中', '计划中', '进行中', '进行中']
    }
    
    df = pd.DataFrame(data)
    
    print("\n原始数据:")
    print(df.to_string(index=False))
    print(f"\n唯一项目数: {df['项目名称'].nunique()}")
    
    # 合并重复项
    matcher = ProjectNameMatcher()
    df_merged = matcher.merge_duplicates(
        df, 
        name_column='项目名称',
        threshold=0.85,
        keep='shortest'  # 保留最短的名称
    )
    
    print("\n合并后的数据:")
    print(df_merged[['项目名称', 'merged_name', '负责人', '预算', '状态']].to_string(index=False))
    print(f"\n合并后唯一项目数: {df_merged['merged_name'].nunique()}")
    
    # 按合并后的名称分组统计
    print("\n按合并名称统计:")
    summary = df_merged.groupby('merged_name').agg({
        '负责人': lambda x: ', '.join(x.unique()),
        '预算': 'sum',
        '状态': lambda x: ', '.join(x.unique())
    }).reset_index()
    print(summary.to_string(index=False))
    
    return df_merged


def demo_batch_match():
    """演示批量匹配"""
    print("\n" + "=" * 60)
    print("示例 5: 批量匹配项目名称")
    print("=" * 60)
    
    # 源系统的项目名称
    source_names = [
        "数据分析平台",
        "用户权限管理",
        "订单管理",
        "报表生成器",
    ]
    
    # 目标系统的项目名称
    target_names = [
        "数据分析系统",
        "数据可视化平台",
        "用户管理系统",
        "权限管理模块",
        "订单处理系统",
        "订单跟踪系统",
        "财务报表系统",
        "报表统计工具",
    ]
    
    matcher = ProjectNameMatcher()
    
    print(f"\n源系统项目数: {len(source_names)}")
    print(f"目标系统项目数: {len(target_names)}")
    print("\n匹配结果:\n")
    
    results = matcher.batch_match(
        source_names,
        target_names,
        threshold=0.6,
        method='sequence'
    )
    
    print(results.to_string(index=False))


def demo_chinese_pinyin():
    """演示中文拼音匹配"""
    print("\n" + "=" * 60)
    print("示例 6: 中文拼音匹配（可选功能）")
    print("=" * 60)
    
    try:
        matcher = ChineseNameMatcher(use_pinyin=True)
        
        test_pairs = [
            ("数据分析", "shuju fenxi"),
            ("用户管理", "yonghu guanli"),
            ("项目管理工具", "xiangmu guanli gongju"),
        ]
        
        print("\n中文-拼音匹配测试:\n")
        for chinese, pinyin in test_pairs:
            score_normal = matcher.similarity_ratio(chinese, pinyin, use_pinyin=False)
            score_pinyin = matcher.similarity_ratio(chinese, pinyin, use_pinyin=True)
            
            print(f"中文: {chinese}")
            print(f"拼音: {pinyin}")
            print(f"  普通匹配: {score_normal:.4f}")
            print(f"  拼音匹配: {score_pinyin:.4f}")
            print()
    
    except Exception as e:
        print(f"\n拼音匹配功能不可用（需要安装 pypinyin）")
        print(f"安装命令: pip install pypinyin")


def main():
    """运行所有示例"""
    print("\n" + "=" * 60)
    print("项目名称相似求同模块 - 使用示例")
    print("=" * 60)
    
    # 运行各个示例
    demo_basic_similarity()
    demo_find_similar()
    demo_find_duplicates()
    df_merged = demo_merge_dataframe()
    demo_batch_match()
    demo_chinese_pinyin()
    
    # 保存结果
    output_dir = project_root / 'outputs'
    output_dir.mkdir(parents=True, exist_ok=True)
    
    output_path = output_dir / 'name_matching_result.xlsx'
    save_dataframe(df_merged, output_path)
    
    print("\n" + "=" * 60)
    print("示例运行完成！")
    print("=" * 60)
    print(f"结果已保存至: {output_path}")
    print("=" * 60)


if __name__ == '__main__':
    main()
