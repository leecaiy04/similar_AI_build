#!/usr/bin/env python3
"""
AI 增强匹配器演示脚本

展示多层次判断和 AI 语义理解能力
"""

import sys
from pathlib import Path

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import pandas as pd
from src.name_matcher.ai_enhanced import AIEnhancedMatcher
from src.utils import setup_logger, save_dataframe

setup_logger()


def demo_basic_comparison():
    """基础对比演示"""
    print("=" * 70)
    print("示例 1: AI 增强匹配 - 基础对比")
    print("=" * 70)
    
    # 创建匹配器（启用 Embedding，不启用 LLM）
    matcher = AIEnhancedMatcher(use_embedding=True, use_llm=False)
    
    # 测试用例
    test_cases = [
        # (名称1, 名称2, 预期结果)
        ("数据分析平台", "数据分析系统", "同一项目"),
        ("数据分析平台v1.0", "数据分析平台v2.0", "同一项目（版本差异）"),
        ("用户管理系统", "用户权限管理", "可能同一"),
        ("订单管理", "订单处理系统", "可能同一"),
        ("数据分析平台", "数据可视化工具", "不同项目"),
        ("财务报表系统", "人力资源管理", "不同项目"),
        ("CRM系统", "客户关系管理", "同一项目（缩写）"),
        ("Data Analysis", "数据分析", "同一项目（中英文）"),
    ]
    
    print("\n详细对比结果:\n")
    print(f"{'项目A':<25} {'项目B':<25} {'结果':<10} {'分数':<8} {'说明'}")
    print("-" * 100)
    
    for name1, name2, expected in test_cases:
        is_same, score, reason, features = matcher.is_same_project(
            name1, name2, return_details=True
        )
        
        result_text = "✓ 同一" if is_same else "✗ 不同"
        
        print(f"{name1:<25} {name2:<25} {result_text:<10} {score:.4f}  {reason}")
        
        # 显示详细特征
        feature_str = " | ".join([f"{k}: {v:.3f}" for k, v in features.items()])
        print(f"  特征: {feature_str}")
        print()


def demo_version_handling():
    """版本号处理演示"""
    print("\n" + "=" * 70)
    print("示例 2: 版本号智能处理")
    print("=" * 70)
    
    matcher = AIEnhancedMatcher(use_embedding=True)
    
    version_cases = [
        "项目管理系统",
        "项目管理系统v1",
        "项目管理系统v2.0",
        "项目管理系统 (旧版)",
        "项目管理系统 [新]",
        "项目管理平台v3.1",
    ]
    
    print(f"\n基准: {version_cases[0]}\n")
    print(f"{'对比名称':<30} {'核心名称':<20} {'相似度':<10} {'判断'}")
    print("-" * 80)
    
    base_name = version_cases[0]
    for name in version_cases[1:]:
        core = matcher.extract_core_name(name)
        is_same, score, _ = matcher.is_same_project(base_name, name)
        result = "✓ 同一项目" if is_same else "✗ 不同"
        
        print(f"{name:<30} {core:<20} {score:.4f}     {result}")


def demo_semantic_understanding():
    """语义理解演示"""
    print("\n" + "=" * 70)
    print("示例 3: 语义理解能力")
    print("=" * 70)
    
    matcher = AIEnhancedMatcher(use_embedding=True)
    
    semantic_cases = [
        ("用户管理系统", "User Management System", "中英文"),
        ("数据分析平台", "数据分析系统", "近义词"),
        ("订单管理", "订单处理", "近义词"),
        ("客户关系管理", "CRM", "缩写"),
        ("企业资源计划", "ERP系统", "缩写"),
        ("数据分析", "数据可视化", "相关但不同"),
        ("用户管理", "权限管理", "相关但不同"),
    ]
    
    print(f"\n{'项目A':<25} {'项目B':<25} {'类型':<12} {'相似度':<10} {'判断'}")
    print("-" * 90)
    
    for name1, name2, case_type in semantic_cases:
        is_same, score, _ = matcher.is_same_project(name1, name2)
        result = "✓ 同一" if is_same else "✗ 不同"
        
        print(f"{name1:<25} {name2:<25} {case_type:<12} {score:.4f}     {result}")


def demo_batch_comparison():
    """批量对比演示"""
    print("\n" + "=" * 70)
    print("示例 4: 批量项目对比")
    print("=" * 70)
    
    matcher = AIEnhancedMatcher(use_embedding=True)
    
    # 模拟项目列表（含重复项）
    projects = [
        "数据分析平台",
        "数据分析系统v2",
        "用户管理系统",
        "用户权限管理平台",
        "订单处理系统",
        "订单管理工具",
        "财务报表系统",
        "数据可视化平台",
        "客户关系管理",
        "CRM系统",
    ]
    
    print(f"\n项目列表 ({len(projects)} 个):")
    for i, name in enumerate(projects, 1):
        print(f"  {i}. {name}")
    
    print("\n开始批量对比...")
    results = matcher.batch_compare(projects, threshold=0.7)
    
    print(f"\n找到 {len(results)} 对相似项目:\n")
    
    if len(results) > 0:
        # 只显示关键列
        display_cols = ['项目A', '项目B', '相似度', '判断']
        print(results[display_cols].to_string(index=False))
    else:
        print("未找到相似项目对")
    
    return results


def demo_feature_weights():
    """特征权重对比"""
    print("\n" + "=" * 70)
    print("示例 5: 特征权重影响分析")
    print("=" * 70)
    
    test_pair = ("数据分析平台", "数据分析系统")
    
    # 不同权重配置
    weight_configs = [
        {
            'name': '均衡模式',
            'weights': {
                'edit': 0.20,
                'token_set': 0.20,
                'ngram': 0.20,
                'embedding': 0.40,
            }
        },
        {
            'name': '传统算法优先',
            'weights': {
                'edit': 0.30,
                'token_set': 0.30,
                'ngram': 0.30,
                'embedding': 0.10,
            }
        },
        {
            'name': 'AI语义优先',
            'weights': {
                'edit': 0.10,
                'token_set': 0.10,
                'ngram': 0.10,
                'embedding': 0.70,
            }
        }
    ]
    
    print(f"\n测试项目对: '{test_pair[0]}' vs '{test_pair[1]}'\n")
    print(f"{'模式':<20} {'最终分数':<12} {'判断':<10} {'特征详情'}")
    print("-" * 90)
    
    for config in weight_configs:
        matcher = AIEnhancedMatcher(
            use_embedding=True,
            weights=config['weights']
        )
        
        is_same, score, _, features = matcher.is_same_project(
            test_pair[0], test_pair[1], return_details=True
        )
        
        result = "同一项目" if is_same else "不同项目"
        feature_str = ", ".join([f"{k}:{v:.3f}" for k, v in features.items()])
        
        print(f"{config['name']:<20} {score:.4f}       {result:<10} {feature_str}")


def demo_real_world_scenario():
    """真实场景演示"""
    print("\n" + "=" * 70)
    print("示例 6: 真实场景 - 项目清单去重")
    print("=" * 70)
    
    # 模拟从不同数据源导入的项目清单
    df = pd.DataFrame({
        '项目名称': [
            '数据分析平台',
            '数据分析平台v2.0',
            '用户管理系统',
            '用户权限管理',
            '订单处理系统',
            '订单管理',
            'CRM系统',
            '客户关系管理平台',
            '财务报表工具',
            '报表系统',
        ],
        '部门': ['技术部', '技术部', '运营部', '运营部', '销售部', '销售部', '销售部', '销售部', '财务部', '财务部'],
        '预算': [100, 120, 80, 85, 70, 75, 90, 95, 60, 65],
        '状态': ['进行中', '进行中', '已完成', '进行中', '已完成', '进行中', '计划中', '进行中', '已完成', '计划中']
    })
    
    print("\n原始数据:")
    print(df.to_string(index=False))
    print(f"\n唯一项目数: {df['项目名称'].nunique()}")
    
    # 使用 AI 增强匹配器去重
    matcher = AIEnhancedMatcher(use_embedding=True)
    
    print("\n正在识别重复项目...")
    
    # 识别相似项
    similar_pairs = matcher.batch_compare(df['项目名称'].unique(), threshold=0.75)
    
    if len(similar_pairs) > 0:
        print(f"\n发现 {len(similar_pairs)} 对可能重复的项目:\n")
        print(similar_pairs[['项目A', '项目B', '相似度', '判断']].to_string(index=False))
        
        # 建议合并策略
        print("\n建议合并策略:")
        for _, row in similar_pairs.iterrows():
            if row['相似度'] >= 0.9:
                print(f"  • '{row['项目A']}' 和 '{row['项目B']}' 高度相似，建议合并")
            elif row['相似度'] >= 0.75:
                print(f"  • '{row['项目A']}' 和 '{row['项目B']}' 可能相同，建议人工确认")
    else:
        print("\n未发现明显重复项目")
    
    return df, similar_pairs


def main():
    """运行所有演示"""
    print("\n" + "=" * 70)
    print("AI 增强项目名称匹配器 - 完整演示")
    print("=" * 70)
    
    try:
        # 运行各个演示
        demo_basic_comparison()
        demo_version_handling()
        demo_semantic_understanding()
        batch_results = demo_batch_comparison()
        demo_feature_weights()
        df, similar_pairs = demo_real_world_scenario()
        
        # 保存结果
        output_dir = project_root / 'outputs'
        output_dir.mkdir(parents=True, exist_ok=True)
        
        if len(batch_results) > 0:
            save_dataframe(batch_results, output_dir / 'ai_batch_comparison.xlsx')
        
        if len(similar_pairs) > 0:
            save_dataframe(similar_pairs, output_dir / 'ai_similar_pairs.xlsx')
        
        print("\n" + "=" * 70)
        print("演示完成！")
        print("=" * 70)
        
        if len(batch_results) > 0:
            print(f"批量对比结果已保存: {output_dir / 'ai_batch_comparison.xlsx'}")
        if len(similar_pairs) > 0:
            print(f"相似项对已保存: {output_dir / 'ai_similar_pairs.xlsx'}")
        
        print("\n关键优势:")
        print("  ✓ 多层次判断（规则 + 传统算法 + AI 语义）")
        print("  ✓ 智能版本号处理")
        print("  ✓ 中英文语义理解")
        print("  ✓ 缩写与全称匹配")
        print("  ✓ 可配置权重和阈值")
        print("  ✓ 详细特征输出，可解释性强")
        
        print("\n提示:")
        print("  • 当前使用 Sentence-BERT 本地模型（免费，离线）")
        print("  • 如需更高精度，可启用 LLM 判断（需配置 API）")
        print("  • 安装依赖: pip install sentence-transformers scikit-learn")
        print("=" * 70)
        
    except Exception as e:
        print(f"\n错误: {e}")
        print("\n可能的原因:")
        print("  1. 缺少依赖: pip install sentence-transformers scikit-learn")
        print("  2. 模型下载失败（首次运行需要下载模型）")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    main()
