# 项目名称同一性判断方案

## 方案概述

本方案通过**多层次特征提取 + 传统算法 + AI语义理解**的混合架构，实现高精度的项目名称同一性判断。

---

## 架构设计

### 整体流程

```
输入项目名称对
    ↓
┌──────────────────────────────────┐
│   第一层：规则预处理层           │
│   - 完全匹配                     │
│   - 标准化规则                   │
│   - 黑白名单                     │
└──────────────────────────────────┘
    ↓
┌──────────────────────────────────┐
│   第二层：传统算法层             │
│   - 编辑距离                     │
│   - 词集相似度                   │
│   - N-gram                       │
│   - TF-IDF                       │
└──────────────────────────────────┘
    ↓
┌──────────────────────────────────┐
│   第三层：AI语义理解层           │
│   - 文本嵌入向量（Embedding）    │
│   - 语义相似度计算               │
│   - LLM 二次判断                 │
└──────────────────────────────────┘
    ↓
┌──────────────────────────────────┐
│   决策融合层                     │
│   - 多维度特征加权               │
│   - 置信度评分                   │
│   - 阈值自适应                   │
└──────────────────────────────────┘
    ↓
输出：是否同一项目 + 置信度分数
```

---

## 详细技术方案

### 第一层：规则预处理层

#### 1.1 完全匹配
- **标准化后完全匹配** → 直接判定为同一项目
- 示例：`"Data Analysis"` vs `"data-analysis"` → 同一

#### 1.2 版本号处理
```python
规则：
- 移除版本标识：v1, v2, 2.0, V3.1, (旧版), [新]
- 提取核心名称
- 示例：
  "数据分析平台v1.0" → "数据分析平台"
  "数据分析平台v2.0" → "数据分析平台"
  → 判定为同一项目的不同版本
```

#### 1.3 别名词典
```python
预定义别名映射：
{
    "系统": ["system", "平台", "platform"],
    "管理": ["management", "admin", "后台"],
    "数据": ["data", "信息", "资料"],
    "分析": ["analysis", "analytics", "统计"]
}
```

#### 1.4 黑白名单
- **白名单**：已知同一项目的名称对
- **黑名单**：已知不同项目的名称对（避免误判）

---

### 第二层：传统算法层

#### 2.1 字符级算法

**编辑距离（Levenshtein）**
```python
优点：对拼写错误、字符差异敏感
适用场景：
- "用户管理系统" vs "用户管里系统" (拼写错误)
- "DataAnalysis" vs "DataAnalytics"
```

**最长公共子序列（LCS）**
```python
优点：对插入、删除不敏感
适用场景：
- "项目管理" vs "项目管理工具"
- "数据分析" vs "大数据分析"
```

#### 2.2 词级算法

**词集相似度（Token Set Ratio）**
```python
将名称分词后计算交集/并集
示例：
  "数据分析平台系统" → {"数据", "分析", "平台", "系统"}
  "数据平台分析工具" → {"数据", "平台", "分析", "工具"}
  交集: {"数据", "分析", "平台"}
  Jaccard = 3 / 5 = 0.6
```

**N-gram 相似度**
```python
提取 2-gram 或 3-gram 片段
示例 (2-gram)：
  "数据分析" → ["数据", "据分", "分析"]
  "数据统计" → ["数据", "据统", "统计"]
  相似度 = 共同 n-gram 数量 / 总 n-gram 数量
```

#### 2.3 向量化算法

**TF-IDF + Cosine Similarity**
```python
优点：考虑词的重要性
流程：
1. 构建所有项目名称的语料库
2. 计算每个词的 TF-IDF 权重
3. 将名称向量化
4. 计算余弦相似度
```

---

### 第三层：AI 语义理解层

#### 3.1 文本嵌入向量（Embedding）

**方案 A：Sentence-BERT（推荐）**
```python
from sentence_transformers import SentenceTransformer

# 使用多语言模型
model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')

# 生成向量
embedding1 = model.encode("数据分析平台")
embedding2 = model.encode("数据分析系统")

# 计算余弦相似度
from sklearn.metrics.pairwise import cosine_similarity
similarity = cosine_similarity([embedding1], [embedding2])[0][0]
```

**优点**：
- 捕获语义信息（"平台" vs "系统" 语义接近）
- 支持中英文
- 离线运行，无需 API 调用

**方案 B：OpenAI Embeddings**
```python
import openai

# 获取嵌入向量
response = openai.Embedding.create(
    model="text-embedding-3-small",
    input=["数据分析平台", "数据分析系统"]
)

embedding1 = response['data'][0]['embedding']
embedding2 = response['data'][1]['embedding']
```

**优点**：
- 更高的语义理解能力
- 支持更长的文本

**缺点**：
- 需要 API 调用
- 有成本

#### 3.2 LLM 智能判断

**方案 A：轻量级二分类判断**
```python
prompt = f"""
请判断以下两个项目名称是否指向同一个项目：

项目名称A: {name1}
项目名称B: {name2}

判断标准：
- 核心功能相同
- 语义含义一致
- 忽略版本号、平台差异、表述方式差异

请仅回答"是"或"否"。
"""
```

**方案 B：结构化输出判断**
```python
prompt = f"""
请分析以下两个项目名称：

项目A: {name1}
项目B: {name2}

请以 JSON 格式返回分析结果：
{{
    "is_same": true/false,
    "confidence": 0.0-1.0,
    "reason": "判断原因",
    "core_function_a": "项目A的核心功能",
    "core_function_b": "项目B的核心功能",
    "key_differences": ["主要差异点1", "差异点2"]
}}

分析维度：
1. 核心业务功能是否一致
2. 目标用户群体是否相同
3. 技术实现方式（如有明显差异）
4. 版本、平台等非本质差异忽略
"""
```

**方案 C：Few-shot 学习**
```python
prompt = f"""
任务：判断两个项目名称是否指向同一个项目。

示例1：
项目A: 用户管理系统
项目B: 用户权限管理平台
判断: 是（核心都是用户权限管理）

示例2：
项目A: 数据分析平台
项目B: 数据可视化工具
判断: 否（分析≠可视化）

示例3：
项目A: 订单管理系统v1
项目B: 订单管理系统v2
判断: 是（仅版本不同）

现在判断：
项目A: {name1}
项目B: {name2}
判断: 
"""
```

#### 3.3 混合策略

**阶段性调用 LLM**
```python
if 传统算法相似度 > 0.9:
    return True  # 高置信度，无需 LLM
elif 传统算法相似度 < 0.5:
    return False  # 明显不同，无需 LLM
else:
    # 边界情况，调用 LLM
    return llm_judge(name1, name2)
```

**优点**：
- 降低 API 调用成本
- 提高整体判断速度

---

### 第四层：决策融合层

#### 4.1 多维度特征加权

```python
特征向量 = [
    编辑距离相似度,      # 权重: 0.15
    词集相似度,          # 权重: 0.20
    N-gram相似度,        # 权重: 0.15
    TF-IDF相似度,        # 权重: 0.10
    Embedding相似度,     # 权重: 0.30
    LLM判断分数          # 权重: 0.10
]

最终分数 = Σ(特征 × 权重)
```

#### 4.2 置信度评分

```python
if 最终分数 >= 0.9:
    return "同一项目", 置信度="高"
elif 最终分数 >= 0.7:
    return "可能同一项目", 置信度="中"
elif 最终分数 >= 0.5:
    return "需要人工确认", 置信度="低"
else:
    return "不同项目", 置信度="高"
```

#### 4.3 自适应阈值

```python
# 根据历史标注数据动态调整阈值
if 有标注数据:
    通过 ROC 曲线找到最优阈值
    考虑精确率和召回率的平衡
else:
    使用默认阈值 0.75
```

---

## 实现建议

### 轻量级方案（无需外部 API）

```python
架构：
1. 规则预处理 (100%)
2. 传统算法 (编辑距离 + 词集 + N-gram)
3. Sentence-BERT Embedding（本地模型）
4. 加权融合

优点：
- 无需 API，完全离线
- 响应速度快（毫秒级）
- 无额外成本
- 精度可达 85-90%
```

### 标准方案（少量 API 调用）

```python
架构：
1. 规则预处理
2. 传统算法 + Sentence-BERT
3. 边界情况调用 LLM（10-20%）
4. 加权融合

优点：
- 平衡精度和成本
- LLM 仅处理困难样本
- 精度可达 90-95%
```

### 高精度方案（完全 LLM 增强）

```python
架构：
1. 规则预处理
2. 所有样本使用 OpenAI Embeddings
3. 困难样本使用 LLM 结构化判断
4. 用户反馈持续学习

优点：
- 最高精度（95%+）
- 能处理复杂语义
- 可解释性强（LLM 输出原因）
```

---

## 特殊场景处理

### 1. 缩写与全称
```python
"CRM" vs "客户关系管理系统"
→ 维护缩写词典
→ 或通过 LLM 语义判断
```

### 2. 中英文混合
```python
"数据分析 Platform" vs "Data Analysis 平台"
→ 统一语言标准化
→ 使用多语言 Embedding
```

### 3. 领域专有名词
```python
"ERP系统" vs "企业资源计划"
→ 构建领域知识图谱
→ 专有名词映射表
```

### 4. 模糊边界
```python
"用户管理" vs "权限管理"
→ 功能相关但不同
→ 需要 LLM 细粒度判断
```

---

## 性能优化

### 1. 缓存机制
```python
# 缓存已判断的名称对
cache = {
    ("项目A", "项目B"): (True, 0.95),
    ...
}
```

### 2. 批量 Embedding
```python
# 一次性生成所有项目的嵌入向量
embeddings = model.encode(all_project_names, batch_size=32)
# 后续仅需查表和计算相似度
```

### 3. 分层索引
```python
# 使用 FAISS 或 Annoy 构建向量索引
# 快速检索相似项目
```

---

## 评估指标

### 准确率指标
- **精确率（Precision）**: 判定为"同一项目"中真正相同的比例
- **召回率（Recall）**: 实际相同的项目被正确识别的比例
- **F1 Score**: 精确率和召回率的调和平均

### 业务指标
- **自动化率**: 无需人工确认的样本比例
- **误判成本**: False Positive vs False Negative 的业务影响

---

## 完整实现示例

```python
class AdvancedProjectMatcher:
    def __init__(self):
        # 加载 Sentence-BERT 模型
        self.embedding_model = SentenceTransformer('model-name')
        
        # 加载别名词典
        self.alias_dict = load_alias_dict()
        
        # 加载白名单/黑名单
        self.whitelist = load_whitelist()
        self.blacklist = load_blacklist()
    
    def is_same_project(self, name1, name2):
        # 第一层：规则判断
        if (name1, name2) in self.whitelist:
            return True, 1.0, "白名单匹配"
        
        if (name1, name2) in self.blacklist:
            return False, 1.0, "黑名单排除"
        
        core1 = self.extract_core_name(name1)
        core2 = self.extract_core_name(name2)
        
        if core1 == core2:
            return True, 0.95, "核心名称完全匹配"
        
        # 第二层：传统算法
        edit_sim = self.levenshtein_similarity(name1, name2)
        token_sim = self.token_set_similarity(name1, name2)
        ngram_sim = self.ngram_similarity(name1, name2)
        
        # 第三层：AI 语义
        emb_sim = self.embedding_similarity(name1, name2)
        
        # 特征融合
        score = (
            edit_sim * 0.15 +
            token_sim * 0.20 +
            ngram_sim * 0.15 +
            emb_sim * 0.50
        )
        
        # 边界情况调用 LLM
        if 0.5 < score < 0.8:
            llm_result = self.llm_judge(name1, name2)
            score = score * 0.7 + llm_result * 0.3
        
        is_same = score >= 0.75
        confidence = "高" if abs(score - 0.75) > 0.15 else "中"
        
        return is_same, score, confidence
```

---

## 总结与建议

### 推荐方案组合

**阶段一（MVP）**: 规则 + 传统算法 + Sentence-BERT
- 成本：低
- 精度：85-90%
- 速度：快

**阶段二（优化）**: 加入 LLM 边界判断
- 成本：中
- 精度：90-95%
- 可解释性：强

**阶段三（完善）**: 用户反馈 + 持续学习
- 成本：中-高
- 精度：95%+
- 自适应能力：强

### 关键成功因素

1. **标注数据质量**: 构建高质量的标注数据集用于调优
2. **领域知识**: 维护行业术语、缩写词典
3. **持续优化**: 根据用户反馈不断调整权重和阈值
4. **平衡取舍**: 精度、速度、成本的权衡
