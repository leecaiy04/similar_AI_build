# 快速开始指南

## 5 分钟快速上手

### 步骤 1: 安装依赖

```bash
# 进入项目目录
cd /vol1/1000/code/similar_AI_build

# 基础依赖（必需）
pip install pandas numpy loguru

# AI 语义匹配（强烈推荐）
pip install sentence-transformers scikit-learn torch

# 中文拼音支持（可选）
pip install pypinyin
```

**注意**: 首次安装 `sentence-transformers` 会下载约 100MB 的模型文件。

---

### 步骤 2: 基础示例

创建文件 `test_basic.py`:

```python
import sys
sys.path.insert(0, '/vol1/1000/code/similar_AI_build')

from src.name_matcher.ai_enhanced import AIEnhancedMatcher

# 创建匹配器
matcher = AIEnhancedMatcher(use_embedding=True)

# 测试 1: 版本差异
is_same, score, reason = matcher.is_same_project(
    "数据分析平台v1.0",
    "数据分析平台v2.0"
)
print(f"测试1: {is_same} (分数: {score:.4f})")
print(f"原因: {reason}\n")

# 测试 2: 近义词
is_same, score, reason = matcher.is_same_project(
    "数据分析平台",
    "数据分析系统"
)
print(f"测试2: {is_same} (分数: {score:.4f})")
print(f"原因: {reason}\n")

# 测试 3: 不同项目
is_same, score, reason = matcher.is_same_project(
    "数据分析平台",
    "用户管理系统"
)
print(f"测试3: {is_same} (分数: {score:.4f})")
print(f"原因: {reason}")
```

运行:
```bash
python test_basic.py
```

---

### 步骤 3: 批量对比

创建文件 `test_batch.py`:

```python
import sys
sys.path.insert(0, '/vol1/1000/code/similar_AI_build')

from src.name_matcher.ai_enhanced import AIEnhancedMatcher

# 创建匹配器
matcher = AIEnhancedMatcher(use_embedding=True)

# 项目列表
projects = [
    "数据分析平台",
    "数据分析系统v2",
    "用户管理系统",
    "用户权限管理平台",
    "订单处理系统",
    "订单管理工具",
]

print(f"正在比较 {len(projects)} 个项目...\n")

# 批量对比
results = matcher.batch_compare(projects, threshold=0.75)

if len(results) > 0:
    print("找到以下相似项目对:\n")
    for _, row in results.iterrows():
        print(f"  {row['项目A']} ≈ {row['项目B']}")
        print(f"  相似度: {row['相似度']:.4f}")
        print(f"  判断: {row['判断']}\n")
else:
    print("未找到相似项目")
```

运行:
```bash
python test_batch.py
```

---

### 步骤 4: 真实场景 - Excel 去重

创建文件 `test_excel.py`:

```python
import sys
sys.path.insert(0, '/vol1/1000/code/similar_AI_build')

import pandas as pd
from src.name_matcher.ai_enhanced import AIEnhancedMatcher

# 模拟 Excel 数据
df = pd.DataFrame({
    '项目名称': [
        '数据分析平台',
        '数据分析平台v2.0',
        '用户管理系统',
        '用户权限管理',
        'CRM系统',
        '客户关系管理平台',
    ],
    '预算': [100, 120, 80, 85, 90, 95],
    '状态': ['进行中', '进行中', '已完成', '进行中', '计划中', '进行中']
})

print("原始数据:")
print(df)
print(f"\n唯一项目数: {df['项目名称'].nunique()}\n")

# 创建匹配器
matcher = AIEnhancedMatcher(use_embedding=True)

# 识别重复项
print("正在识别重复项目...\n")
duplicates = matcher.batch_compare(
    df['项目名称'].unique(),
    threshold=0.8
)

if len(duplicates) > 0:
    print("发现以下可能重复的项目:\n")
    for _, row in duplicates.iterrows():
        print(f"  {row['项目A']} ≈ {row['项目B']}")
        print(f"  相似度: {row['相似度']:.4f}")
        if row['相似度'] >= 0.9:
            print(f"  建议: 高度相似，建议合并\n")
        else:
            print(f"  建议: 可能相同，建议人工确认\n")
else:
    print("未发现重复项目")
```

运行:
```bash
python test_excel.py
```

---

### 步骤 5: 运行完整演示

```bash
# 运行 AI 增强演示（6 个完整示例）
python scripts/ai_matching_demo.py

# 运行基础匹配演示
python scripts/name_matching_demo.py
```

---

## 常见使用场景

### 场景 1: 简单判断

```python
from src.name_matcher.ai_enhanced import AIEnhancedMatcher

matcher = AIEnhancedMatcher(use_embedding=True)

is_same, score, reason = matcher.is_same_project("项目A", "项目B")

if is_same:
    print(f"是同一项目 (置信度: {score:.2%})")
else:
    print(f"不是同一项目 (差异度: {1-score:.2%})")
```

### 场景 2: 获取详细特征

```python
is_same, score, reason, features = matcher.is_same_project(
    "项目A", "项目B",
    return_details=True
)

print(f"编辑距离相似度: {features['edit']:.4f}")
print(f"词集相似度: {features['token_set']:.4f}")
print(f"N-gram相似度: {features['ngram']:.4f}")
print(f"AI语义相似度: {features['embedding']:.4f}")
print(f"综合分数: {score:.4f}")
```

### 场景 3: 智能搜索

```python
def find_similar_projects(query, project_list, top_n=5):
    """查找与查询最相似的项目"""
    matcher = AIEnhancedMatcher(use_embedding=True)
    
    results = []
    for project in project_list:
        _, score, _ = matcher.is_same_project(query, project)
        results.append((project, score))
    
    results.sort(key=lambda x: x[1], reverse=True)
    return results[:top_n]

# 使用
all_projects = ["数据分析平台", "用户管理系统", "订单系统", ...]
matches = find_similar_projects("数据分析", all_projects)

for name, score in matches:
    print(f"{name}: {score:.4f}")
```

### 场景 4: 批量去重

```python
import pandas as pd

df = pd.read_excel('projects.xlsx')

# 找出所有相似项对
matcher = AIEnhancedMatcher(use_embedding=True)
duplicates = matcher.batch_compare(
    df['项目名称'].unique(),
    threshold=0.85
)

# 保存结果
duplicates.to_excel('duplicates.xlsx', index=False)
```

---

## 配置选项

### 1. 启用/禁用嵌入

```python
# 启用嵌入（推荐，精度更高）
matcher = AIEnhancedMatcher(use_embedding=True)

# 禁用嵌入（速度更快，但精度较低）
matcher = AIEnhancedMatcher(use_embedding=False)
```

### 2. 调整特征权重

```python
# 默认权重
matcher = AIEnhancedMatcher(
    weights={
        'edit': 0.15,
        'token_set': 0.20,
        'ngram': 0.15,
        'embedding': 0.50,
    }
)

# 强调字符精确性
matcher = AIEnhancedMatcher(
    weights={
        'edit': 0.40,
        'token_set': 0.30,
        'ngram': 0.20,
        'embedding': 0.10,
    }
)

# 强调语义理解
matcher = AIEnhancedMatcher(
    weights={
        'edit': 0.10,
        'token_set': 0.10,
        'ngram': 0.10,
        'embedding': 0.70,
    }
)
```

### 3. 调整阈值

```python
# 宽松模式（召回率优先）
results = matcher.batch_compare(projects, threshold=0.65)

# 标准模式（平衡）
results = matcher.batch_compare(projects, threshold=0.75)

# 严格模式（精确率优先）
results = matcher.batch_compare(projects, threshold=0.90)
```

### 4. LLM 边界判断（可选）

```python
matcher = AIEnhancedMatcher(
    use_embedding=True,
    use_llm=True,  # 启用 LLM
    llm_threshold_range=(0.5, 0.8)  # 仅在此范围内调用 LLM
)
```

**注意**: 需要在 `ai_enhanced.py` 中实现 `llm_judge()` 方法。

---

## 性能优化技巧

### 1. 预热嵌入缓存

```python
# 对于大量项目，预先生成嵌入向量
matcher = AIEnhancedMatcher(use_embedding=True)

for name in all_project_names:
    matcher.get_embedding(name)

# 后续查询将使用缓存，速度更快
```

### 2. 批量处理

```python
# 使用 batch_compare 而不是循环调用 is_same_project
results = matcher.batch_compare(projects, threshold=0.75)
```

### 3. 清理缓存

```python
# 处理完成后清理缓存释放内存
matcher.clear_cache()
```

---

## 故障排查

### 问题 1: 首次运行很慢

**原因**: 首次下载 Sentence-BERT 模型

**解决**: 等待下载完成，后续运行会很快

### 问题 2: 模型下载失败

**解决**: 
```bash
# 手动指定镜像
export HF_ENDPOINT=https://hf-mirror.com
pip install sentence-transformers
```

### 问题 3: 内存不足

**解决**:
1. 使用更小的模型
2. 分批处理项目
3. 及时清理缓存

### 问题 4: 中文匹配不准

**解决**:
1. 确保使用多语言模型
2. 扩展中文别名词典
3. 调高 embedding 权重

---

## 下一步

- 阅读 [完整文档](docs/ai_matcher_guide.md)
- 查看 [方案设计](docs/project_name_identity_solution.md)
- 运行 [演示脚本](scripts/ai_matching_demo.py)
- 编写单元测试
- 集成到你的项目中

---

## 获取帮助

如遇到问题，请参考：
- [使用指南](docs/ai_matcher_guide.md)
- [方案设计文档](docs/project_name_identity_solution.md)
- [演示脚本](scripts/)

---

**祝使用愉快！**
