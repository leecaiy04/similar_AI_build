"""
测试项目名称匹配模块
"""

import pytest
import pandas as pd
from src.name_matcher import ProjectNameMatcher, ChineseNameMatcher


class TestProjectNameMatcher:
    """测试项目名称匹配器"""
    
    @pytest.fixture
    def matcher(self):
        """创建匹配器实例"""
        return ProjectNameMatcher()
    
    def test_normalize(self, matcher):
        """测试名称标准化"""
        assert matcher.normalize("  Test Project  ") == "test project"
        assert matcher.normalize("Test-Project_2024") == "testproject2024"
        assert matcher.normalize("TEST PROJECT") == "test project"
    
    def test_normalize_case_sensitive(self):
        """测试大小写敏感的标准化"""
        matcher = ProjectNameMatcher(case_sensitive=True)
        assert matcher.normalize("Test Project") == "Test Project"
    
    def test_levenshtein_distance(self, matcher):
        """测试编辑距离"""
        assert matcher.levenshtein_distance("kitten", "sitting") == 3
        assert matcher.levenshtein_distance("abc", "abc") == 0
        assert matcher.levenshtein_distance("", "test") == 4
    
    def test_similarity_ratio_sequence(self, matcher):
        """测试序列相似度"""
        score = matcher.similarity_ratio("project management", "project manage", method='sequence')
        assert 0.7 < score < 1.0
        
        score = matcher.similarity_ratio("test", "test", method='sequence')
        assert score == 1.0
        
        score = matcher.similarity_ratio("abc", "xyz", method='sequence')
        assert score < 0.5
    
    def test_similarity_ratio_levenshtein(self, matcher):
        """测试编辑距离相似度"""
        score = matcher.similarity_ratio("project", "projects", method='levenshtein')
        assert score > 0.8
    
    def test_similarity_ratio_jaccard(self, matcher):
        """测试 Jaccard 相似度"""
        score = matcher.similarity_ratio("abc", "bcd", method='jaccard')
        assert 0.4 < score < 0.6
    
    def test_similarity_ratio_token_set(self, matcher):
        """测试词集相似度"""
        score = matcher.similarity_ratio("data analysis platform", "analysis data", method='token_set')
        assert score > 0.5
    
    def test_find_similar(self, matcher):
        """测试查找相似项目"""
        candidates = [
            "data analysis platform",
            "data analysis system",
            "user management",
            "order processing",
        ]
        
        results = matcher.find_similar("data analysis", candidates, threshold=0.6)
        assert len(results) >= 2
        assert all(score >= 0.6 for _, score in results)
        
        # 验证排序
        scores = [score for _, score in results]
        assert scores == sorted(scores, reverse=True)
    
    def test_find_similar_top_n(self, matcher):
        """测试限制返回数量"""
        candidates = ["test1", "test2", "test3", "test4"]
        results = matcher.find_similar("test", candidates, threshold=0.5, top_n=2)
        assert len(results) <= 2
    
    def test_find_duplicates(self, matcher):
        """测试查找重复项"""
        names = [
            "project v1",
            "project v1.0",
            "project v2",
            "system a",
            "system b",
        ]
        
        duplicates = matcher.find_duplicates(names, threshold=0.85)
        assert isinstance(duplicates, dict)
        
        # "project v1" 和 "project v1.0" 应该被识别为相似
        has_project_group = any(
            "project" in key.lower() and len(similar) > 0 
            for key, similar in duplicates.items()
        )
        assert has_project_group or len(duplicates) == 0  # 取决于阈值
    
    def test_merge_duplicates(self, matcher):
        """测试合并重复项"""
        df = pd.DataFrame({
            'project_name': [
                'data analysis',
                'data analysis v2',
                'user system',
                'user system 2.0',
            ],
            'value': [100, 200, 300, 400]
        })
        
        df_merged = matcher.merge_duplicates(
            df,
            name_column='project_name',
            threshold=0.85,
            keep='first'
        )
        
        assert 'merged_name' in df_merged.columns
        assert len(df_merged) == len(df)
        
        # 验证合并后的唯一名称数量应该减少或相等
        original_unique = df['project_name'].nunique()
        merged_unique = df_merged['merged_name'].nunique()
        assert merged_unique <= original_unique
    
    def test_merge_duplicates_keep_strategies(self, matcher):
        """测试不同的保留策略"""
        df = pd.DataFrame({
            'name': ['abc', 'abcd', 'abcde'],
            'value': [1, 2, 3]
        })
        
        # 测试 shortest
        df_short = matcher.merge_duplicates(df, 'name', threshold=0.8, keep='shortest')
        assert df_short['merged_name'].iloc[0] == 'abc'
        
        # 测试 longest
        df_long = matcher.merge_duplicates(df, 'name', threshold=0.8, keep='longest')
        assert df_long['merged_name'].iloc[0] == 'abcde'
    
    def test_batch_match(self, matcher):
        """测试批量匹配"""
        sources = ['project a', 'project b']
        targets = ['project alpha', 'project beta', 'system c']
        
        results = matcher.batch_match(sources, targets, threshold=0.6)
        
        assert isinstance(results, pd.DataFrame)
        assert '源名称' in results.columns
        assert '匹配名称' in results.columns
        assert '相似度' in results.columns
        assert len(results) >= len(sources)


class TestChineseNameMatcher:
    """测试中文名称匹配器"""
    
    @pytest.fixture
    def matcher(self):
        """创建中文匹配器实例"""
        return ChineseNameMatcher(use_pinyin=False)
    
    def test_normalize_chinese(self, matcher):
        """测试中文名称标准化"""
        assert matcher.normalize("数据分析平台") == "数据分析平台"
        assert matcher.normalize("  数据分析  ") == "数据分析"
    
    def test_similarity_chinese(self, matcher):
        """测试中文相似度"""
        score = matcher.similarity_ratio("数据分析平台", "数据分析系统")
        assert score > 0.7
        
        score = matcher.similarity_ratio("用户管理", "订单管理")
        assert 0.3 < score < 0.7


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
